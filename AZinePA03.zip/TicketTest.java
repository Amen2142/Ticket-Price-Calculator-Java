package PA03;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;

import java.util.Random;

import javax.swing.JOptionPane;
import javax.swing.JTextArea;

public class TicketTest 
{

	/*Array of Audience object*/
	static Audience[] audienceList;

	public static void main(String[] args) 
	{

		/*Input variable declaration and initialization*/
		String name = "";
		int noOfAdvancedays = 0;
		int numberOfAudience = 0;
		int studentStatus = 0;
		int campusStatus = 0;
		String studentID="";
		String ticketNumber = "";

		/*Get number of audience and create the Audience array*/
		while(true) 
		{
			try 
			{
				numberOfAudience = Integer.parseInt(JOptionPane.showInputDialog("Enter the Number of Audience Members:"));
				
				if (numberOfAudience <= 0)
					throw new Exception();
				
			    break;
			} 
			catch (Exception ex)
			{
					JOptionPane.showMessageDialog(null, "Number of Audience is invalid, Try Again!");	
			} 
		} // End while	
		
		audienceList = new Audience[numberOfAudience];
		
		/*Loop over no of audience to create appropriate ticket objects*/
		for (int i = 0; i < numberOfAudience; i++) 
		{
			int leftLimit = 97; // letter 'a'
		    int rightLimit = 122; // letter 'z'
		    int targetLength = 10;
		    Random random = new Random();
		    StringBuilder buffer = new StringBuilder(targetLength);
		    int randomLimit = leftLimit + (int) 
		    (random.nextFloat() * (rightLimit - leftLimit + 1));
		    buffer.append((char) randomLimit);
		    
			ticketNumber = buffer.toString();
		}

		
		while(true) 
		{
			
			try 
			{
				name = JOptionPane.showInputDialog("Enter Audience Member Name: " );
				
				if (name.isEmpty()) 
					JOptionPane.showMessageDialog(null, "Invalid Name Input!");
				
				noOfAdvancedays = Integer.parseInt(JOptionPane.showInputDialog("Enter Number of Days before the event:"));
				if (noOfAdvancedays == 0) 
				{ 
					addWalkupTicket(name, ticketNumber);
					break;
				}
				else 
				{
					// Set boolean statuses
					while (true) 
					{	
						
						try 
						{
							campusStatus = Integer.parseInt(JOptionPane.showInputDialog("Are you a student?: 1=Yes, 0=No"));
							if (campusStatus == 1) 
							{					
								studentID = JOptionPane.showInputDialog("Enter studentID:");
								
								while (true) 
								{
									
									try 
									{
										campusStatus = Integer.parseInt(JOptionPane.showInputDialog("Are you an on-campus student?: 1:Yes 0:No "));
										if (campusStatus == 1) 
										{
											addOncampusAdvanceTicket(name, ticketNumber, noOfAdvancedays, studentID);
											break;
										}
										else if(campusStatus == 0) 
										{
											addOffcampusAdvanceTicket(name, ticketNumber, noOfAdvancedays, studentID);
											break;
										}
										else
											throw new Exception();						
									} 
									
									catch (Exception ex){
										int choice = 0;
										choice = JOptionPane.showConfirmDialog(null, "on-campus status: Invalid Input! \nWould You Like To Continue?");
									    if (choice != 0)
									    	System.exit(0);
									}// end catch
								}// end while
								
								break;
							}
							else if(studentStatus == 0) 
							{
								addAdvancedTicket(name, ticketNumber, noOfAdvancedays);
								break;
							}
							else 
								throw new Exception();
						} // End try	 
						
						catch (Exception ex)
						{					
							int choice = 0;
							choice = JOptionPane.showConfirmDialog(null, "Invalid Student ID Input! \nWould You Like To Continue?");
						    if (choice != 0)
						    	System.exit(0);
						} // End catch
					}// end while
					
				}//end of else of number of days before event
					
				
			} // End outer try
			
			catch (Exception ex)
			{					
				int choice = 0;
				choice = JOptionPane.showConfirmDialog(null, "Invalid number of days! \nWould You Like To Continue?");
				if (choice != 0)
					System.exit(0);
			}// end catch	
		} // End while
		
		display(); // display the unsorted list of audience details
		selectionSort(); // sort the list based on ticketPrice
		display(); //display the sorted list
		writeToFile(); //write the sorted list to output file
	}

	/*Method to create Advanced Ticket object and add to audience array*/
	private static void addAdvancedTicket(String name, String ticketNumber, int days) 
	{
		audienceList[Audience.getNoOfAudience()] = new Audience(name, new AdvancedTicket(ticketNumber, days));
	}

	/*Method to create Off campus Advanced Ticket object and add to audience array*/
	private static void addOffcampusAdvanceTicket(String name, String ticketNumber, int days, String ID) 
	{
		audienceList[Audience.getNoOfAudience()] = new Audience(name, new OncampusStudentAdvanceTicket(ticketNumber, days,ID));
	}

	/*Method to create On campus Advanced Ticket object and add to audience array*/
	private static void addOncampusAdvanceTicket(String name, String ticketNumber, int days, String ID) 
	{
		audienceList[Audience.getNoOfAudience()] = new Audience(name, new OffcampusStudentAdvanceTicket(ticketNumber, days,ID));
	}

	/*Method to create Walkup Ticket object and add to audience array*/
	public static void addWalkupTicket(String name, String ticketNumber)
	{
		audienceList[Audience.getNoOfAudience()] = new Audience(name, new WalkupTicket(ticketNumber));
	}

	/*Method to display audience object details*/
	public static void display()
	{
		String out = "Name\t" + "Ticket Number\t" + "Ticket Price\t" + "Date Purchased\t" + "Days advance\t" + "Student ID\t" + "Is On-campus\n";
		for (int i = 0; i < Audience.getNoOfAudience() ; i++) 
			out += "\n" + audienceList[i];

		JOptionPane.showMessageDialog(null, new JTextArea(out));
	}

	/*Method to sort audience object based on ticketCost using compareTo() method*/
	public static void selectionSort() 
	{
		 Audience currentMin;
		 int currentMinIndex;
		
         for (int i = 0; i < audienceList.length - 1; i++)
         {
           // Find the minimum in the list[i..list.length-1]
           currentMin = audienceList[i];
           currentMinIndex = i;
          
                       
           for (int j = i + 1; j < audienceList.length; j++) 
           {
             if (currentMin.compareTo(audienceList[j]) > 0) 
             {
               currentMin = audienceList[j];
               currentMinIndex = j;
             } 
           }
           // Swap list[i] with list[currentMinIndex] if necessary
           if (currentMinIndex != i) 
           {
             audienceList[currentMinIndex] = audienceList[i];  
             audienceList[i] = currentMin;   
            
           }
         } // End outer for
	}

	/*Method to write audience object details into an output file*/
	public static void writeToFile() 
	{
		// Create a file
		File file = new File("Audience.txt");
	    
		PrintWriter write = null;
		try 
		{
			write = new PrintWriter(file);
		} 
		catch (FileNotFoundException e) 
		{
			e.printStackTrace();
		}

		String out = "Name\t" + "Ticket Number\t" + "Ticket Price\t" + "Date Purchased\t" +
				"Days advance\t" + "Student ID\t" + "Is On-campus\n";
		for (int i =0; i < audienceList.length; i++) 
			out+= "\t\r\n" + audienceList[i].toString();
		
		// Write formatted output to the file
		write.print(out);

		// Close the file
		write.close();

		JOptionPane.showMessageDialog(null, "Done Storing Student Data into a File");

	}

}
