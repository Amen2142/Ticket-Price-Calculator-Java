package PA03;

import java.util.Date;

public class OncampusStudentAdvanceTicket extends AdvancedTicket {

	/* Instance variable declaration*/
	private String studentID;
	private boolean status;

	/*parameterized constructor*/
	public OncampusStudentAdvanceTicket(String number, int days, String ID)
	{
		/*Fill in to instantiate the 1. purchase date variable
		2. ticket number
		3. days
		4. student ID
		5. student status
		6. ticketprice using ticket calculation
		*/
		super.purchaseDate = new Date();
		super.ticketNumber = number;
		super.noOfDaysInAdvance = days;
		this.studentID = ID;
		this.status = false;
		calculateTicket();
	}

	/*getter methods*/
	public String getStudentID()
	{
		return studentID;
	}

	public boolean getStatus()
	{
		return status;
	}

	/*ticket calculation*/
	public void calculateTicket()
	{
		/*fill in to calculate ticket cost based on number of days
		Make sure to include the base charges*/
		if (noOfDaysInAdvance >= 10)
			ticketCost = 15 + onCampusBaseCharge;
		else
			ticketCost = 20 + onCampusBaseCharge;
	}

	@Override //overrided method to print the object details
	public String toString()
	{
		return ticketNumber + "\t$" + 
				String.format("%.2f", ticketCost) + "\t" + 
				purchaseDate.toString()+ "\t" + 
				noOfDaysInAdvance + "\t" + 
				studentID + "\t" + status;
	}
}
