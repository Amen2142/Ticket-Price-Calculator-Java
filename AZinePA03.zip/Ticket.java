package PA03;

import java.util.Date;

public abstract class Ticket implements BaseTicket{

	/* Instance variable declaration*/
	protected String ticketNumber;
	protected double ticketCost;
	protected Date purchaseDate;

	/* Default constructor*/
	Ticket()
	{
		/*Fill in to instantiate only the purchase date variable
			Note that this is the only class that has date variable and
			date package*/
		this.purchaseDate = null;
	}

	/*getter methods*/
	public String getTicketNumber()
	{
		return ticketNumber;
	}

	public Date getPurchaseDate()
	{
		return purchaseDate;
	}

	@Override //method to print ticket number and ticket cost
	public String toString()
	{
		String out = ticketNumber + "\t$" + String.format("%.2f", ticketCost) + "\t" + purchaseDate.toString();
		return out;
	}
	
	public int compareTo(Ticket ticket) 
	{
		// TODO Auto-generated method stub
		return 0;
	}
}
